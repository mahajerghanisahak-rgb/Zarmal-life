package com.zarmallife.app
import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
class MainActivity: AppCompatActivity() {
 private lateinit var web: WebView
 @SuppressLint("SetJavaScriptEnabled")
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  web=WebView(this); setContentView(web)
  web.webViewClient=WebViewClient(); web.webChromeClient=WebChromeClient()
  web.settings.apply { javaScriptEnabled=true; domStorageEnabled=true; databaseEnabled=true; cacheMode=WebSettings.LOAD_DEFAULT; allowFileAccess=true; allowContentAccess=true }
  web.loadUrl("file:///android_asset/index.html")
 }
 @Deprecated("Deprecated in Java")
 override fun onBackPressed(){ if(web.canGoBack()) web.goBack() else super.onBackPressed() }
}
