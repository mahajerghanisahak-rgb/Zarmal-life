Zarmal Life v3
- د اپ په شروع کې Welcome/Start صفحه
- د Start په کلیک سره مستقیم Categories ته ځي
- 3 ژبې: پښتو، دری، English
- فعال Navigation
- Categories, Marketplace, Search, Messages, Post Requirement, Account, Settings
- Offline Local Storage
